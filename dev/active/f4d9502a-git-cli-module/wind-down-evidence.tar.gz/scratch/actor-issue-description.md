Issue release requires an attributable actor, but its library facade only resolves that identity from invocation configuration or Git. Add an explicit typed actor input so isolated callers can release issues without ambient identity, while keeping the existing convenience API and one publication computation.

## Background

The existing in-memory release-result and no-coordinator lifecycle tests provide a claim assignee but no release actor. Those are separate identities: a person or agent may release someone else's claim, and the audit must record who performed the release. Both tests fail on unchanged main when agent environment/configuration and ambient Git identity are unavailable.

## Success Criteria

- [hard] REQ-01: An issue-release facade accepting the canonical Assignee actor releases a claimed issue without resolving environment, user configuration or Git identity, returns the persisted Issue and records the supplied actor independently of the former assignee.
- [hard] REQ-02: Existing convenience release retains its issue-prefix lookup and validation/error precedence, resolves invocation identity only after that existing lookup, and publishes through the same captured lifecycle release producer. A missing issue still fails before actor resolution; absent acting identity still fails without publishing, rather than becoming an anonymous/default actor.
- [hard] REQ-03: Release keeps its current reason, previous-assignee and acting-identity audit data, issue transition/no-op behavior, coupled publication and failure atomicity. Explicit and convenience callers use one release producer, with no alternate mutation or event path.
- [hard] REQ-04: The existing release-result and no-coordinator lifecycle scenarios pass alone and together under sanitized actor inputs, preserving their persisted-result and cleared-assignee assertions. Tests use explicit operation inputs and owned shared fixtures, without process-wide environment/cwd mutation, a fake Git authority or a test-only actor provider.

## Notes

Use the existing canonical Assignee type and captured lifecycle Release request. This is an input capability of the command facade; no new CLI flag, actor vocabulary, identity-resolution priority, storage format, Git floor, coordination backend or actor-setting mechanism is required.

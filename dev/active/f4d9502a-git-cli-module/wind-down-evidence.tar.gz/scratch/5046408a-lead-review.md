# Lead review — 5046408a

Verdict: FAIL at Tier 1. Latest actual full Cargo f604a1fc failed after rework1; diagnostics/repair correction cycle3 is now explicitly authorized by the steward after bounded design R2 PASS. Source implementation reviews have not started. Earlier findings/evidence below retain their original revision context.

Source commit: `0ecd649ce`. Refreshed source: `36f2ea3c1`. All 35 accepted source/doc files preserved byte-for-byte through the metadata-only main refresh; evidence in `5046408a-source-preservation.json`. Main leak check passed and excluded commits are not ancestors. Every changed file is in the accepted design footprint. No untracked source, new target, restored HEAD issue tier or held Git-floor proposal change.

All changed patches were inspected, including final JSON fixture convergence and process-budget lint correction. The only new lead finding in this pass was manual Git setup in the JSON subdirectory test; the worker replaced it with the canonical GitRepository fixture and reran it. All focused checks, format and workspace all-target Clippy passed; complete failure/rerun and RED history is in `5046408a-implementation-result.md`.

## Criteria evidence

REQ-01/02: shared parser and bootstrap select data-relative config or explicit environment override; CLI/init/server supply the captured value. REQ-03: old no-setting derivation and observation context remain; existing default and probe-budget suites retained. REQ-04: nested independent data checkout CLI creation/read passes. REQ-05: code checkout supplies gate evidence and layout cwd; separate data/code and non-Git-code tests prove wiring. REQ-06: claims use data common directory; code selection preserves data and relocated coordination facts. REQ-07: typed setting/supplied/resolved-path errors cover invalid values and raw symlink ancestry. REQ-08: storage-format owns roots/recovery/coordination; deployment links the environment variable there.

## Earlier design findings

- R1 original-root ambiguity: one typed redo v2 binding, required exactly for Worktree operations; session-derived ordinary and staged records; validation before replay writes and removal; original A/new B, unavailable identity and restoration tests.
- R1 selection admission: data-only observation reuses CommitObservation and bounded retry; selection retained through consumer capture; mutation revalidation and claim-first/retained cases; held-writer read test preserves D-25.
- R1 consumer authority: code/data/coordination accessors and subdirectory translation; primary data-only reads avoid fabricated layouts.
- R1 stale HEAD-tier and symlink claims: tier remains absent; raw no-follow ancestry checked before lexical normalization. Steward-approved obsolete issue note removal is metadata-only.
- R2 policy: D-27 recovery precedes new selection/policy; matrix proves both policy changes, partial config and override with exact original audit bytes; no declaration overlay.
- R2 footprint: memory, recover fixture and linked-policy owner included; excluded lease-enforcement test remains unchanged.

## Narrative and deferrals

Maintained design is accepted for implementation. Historical R1/R2/R3 reports, handoffs, investigation status and progress snapshots retain their recorded-time meaning. The deferred repair/relocation mechanism in R1 is explicitly outside the accepted D-26 contract: missing original root must fail safely, not search/rebind. Git-floor transport and subsequent snapshot/archive/diff migration remain separately held work; they are not deferred split-root criteria. No current in-scope deferral identified in the accepted design. Fresh independent review must verify this conclusion against current code.

## Full-gate regression and rework1

Actual full Cargo on36f2ea3c1: fmt/clippy/compilation/buildbudget passed; nextest191pass/4fail before fail-fast, doctests22pass/3fail. Existing in-memory dependency workflows and typed document-error behavior encounter absent configuration ancestry through the new shared data reader. Failed evidence preserved2fb068c61. Required fix: shared no-follow read observation preserves absent-store defaults and admission, without changing existing consumer assertions or mutation root rules.

Tier1.5 audit: zero prior configured code-review runs. Tier2.75 audit: only R1 lines61/63 historical follow-up/proposal markers, superseded by acceptedD26/D27/R3; no current accepted-design deferral. Source footprint remains unchanged.

## Second full gate and accepted correction cycle3

Rework1 ccc0d3cea and refresh70e934693 preserve the original implementation while fixing shared absence discovery and admission; source/evidence freeze376978ed0. Actual full Cargo f604a1fc-d5f9-4548-8dd1-5ed1f0c04d4d cleared the original failures and all25doctests, fmt, clippy, compilation and budget, but stopped after3386passing tests and1failure;1712notrun. Existing config-validation malformed-input contract expects exit4/report but eager full assembly emits exit1. Rework2 reproduced three diagnostic shape failures and invalid-project-name repair failure in unchanged project_config tests (10pass/4fail). These remain open until actual correction validation; the not-run tests are not passes.

Independent diagnostics design R1 FAIL identified an omitted existing storage-test owner; revised ten-file proposal includes it and R2 PASS closes the design finding. The steward accepted semantics/matrix and exact footprint, authorizing one additional bounded cycle3 only. Durable acceptance356f7596a and reference refresh5fa92e83d link the proposal and both reviews. Prior two failures are retained; no automatic retry allowance remains after a further full-gate failure. Source owner follows /tmp/f4d9502a-lead/5046408a-rework-3.md.

Repeated lead audits before dispatch: zero configured code-review records; seven linked design/review documents; only historical originalR1:61/63 deferred markers. Those markers remain superseded by D26/D27/R3. Archived diagnostics proposal/review requests for acceptance are superseded explicitly by the maintained design's accepted amendment, not hidden deferrals. The final implementation review must close diagnosticR1's storage API migration, same admitted index/declaration capture, full sibling assembly, registered findings admission and typed error separation at actual source lines, as well as all prior cumulative findings.

Required next evidence: frozen correction report and exact diff; affected owners and unchanged diagnostic/repair tests, entireCLI/contracts withoutfailfast, fmt/clippy; actual forced full Cargo PASS; then fresh independent Astra/high implementation review and unchanged configured code-review. No source acceptance or landing is recorded here.

# 5046408a cycle3 — newly exposed boundary decision (source frozen)

This is an escalation proposal, not implementation authorization. The accepted ten-file diagnostics correction is implemented and its original report/repair regressions pass. The complete non-fail-fast CLI/contracts run found five failing tests, with two additional mismatching registry arms hidden by the corpus test's first assertion. No assertion or source was changed after that batch. HEAD is `376978ed05c011717ab7c2d88fab54954f045f15`; binary diff SHA256 is `f0c5fd8a3e18932804cd4f02b412b9d1540321d408522733e66601a7ce22b9a3`.

## Evidence and complete boundary sweep

`5046408a-rework-3-cli-contracts.log`: CLI1222 passed/3 failed; contracts548 passed/2 failed. Formatting and all-target Clippy passed afterward; every command is collected. These are focused-suite failures, not another configured full-gate result.

The registry-driven reproduction reads every `failure_lever_registry.toml` arm whose setup contains `malformed-config-toml` or `pending-redo`, creates an owned temporary initialized store, applies the declared setup and invokes the built binary. No process-wide JIT identity was supplied. Full evidence: `5046408a-rework-3-full-boundary-registry.json`.

| Registered arm | Existing expected code | Actual code |
|---|---|---|
| config show | PARSE_ERROR | PARSE_ERROR |
| config validate | VALIDATION_FAILED | VALIDATION_FAILED |
| config show-hierarchy | PARSE_ERROR | PARSE_ERROR |
| doc conformance | PARSE_ERROR | PARSE_ERROR |
| issue list, pending redo | RETRYABLE_CONFLICT | RETRYABLE_CONFLICT |
| item list | INVALID_ARGUMENT | PARSE_ERROR |
| item search | INVALID_ARGUMENT | PARSE_ERROR |
| label namespaces | PARSE_ERROR | PARSE_ERROR |
| recover | recovery_failed | PARSE_ERROR |

The separate universal retryable-read projection also passed its eleven commands in both human and JSON forms (`command_exit_code_projection_tests.rs:977–1013`, log815). It covers archive candidates, doc check-links, graph roots, invariant check, profile diff, query all, issue list, batch-create dry run, item list, label values and validate. The worktree-exec pending-record test is a separate existing owner: it expects GenericError/exit1, the absolute record path, `jit recover`, no child execution and unchanged record bytes; current bootstrap returns RetryableConflict/exit12 before its command runs. Its assertions remain unchanged.

## 1. Permission source preservation — bounded correctness repair

The unreadable-index projection now emits1 instead of5 (log1251–1258). `JsonFileStorage::load_index` correctly uses shared capability admission, but `RepositoryStateStoreError::Io` at `storage/repository_state_store.rs:89–90` is `#[error(transparent)]`. Its source delegates to the inner I/O error's source instead of exposing that concrete I/O error, while `output/failure.rs:484–493` classifies permission failures by searching the source chain for `std::io::Error`.

Recommended repair: preserve the concrete I/O source in the canonical `RepositoryStateStoreError::Io` variant (`#[error("{0}")]` with its existing `#[from]` source); add one owning error-chain assertion in the existing storage test module, then rerun the unchanged projected permission case. Exact owners are already in the ten-file footprint: `crates/jit/src/storage/repository_state_store.rs` and `crates/jit/src/storage/repository_state_store_tests.rs`. No output-code special case or assertion change is needed. Not edited while the material boundary decision is pending.

## 2. Required-root bootstrap versus existing operation adapters

`commands/bootstrap.rs:109–113` must obtain a typed declared-root projection when no env root supplies it. Malformed syntax cannot establish root absence, so it returns the canonical authored parse error before an executor exists. The old item adapter is `CommandExecutor::cached_config`, `commands/mod.rs:2908–2916`, which wraps configuration failure as `InvalidArgumentError("invalid .jit/config.toml: ...")`. Recovery's existing operation adapter is `dispatch/claim.rs:151–157`, wrapping operation failure in `RecoveryFailedError`. Their downstream operation adapters are currently unreachable for this pre-root failure. The malformed-config `recover` case has no pending redo; original-root committed recovery remains before selection.

There are two material alternatives:

**A. Preserve existing operation error adapters.** Extract/reuse the existing typed configuration adapter, so both the downstream item configuration consumer and early required-root declaration failure go through the same item error computation. Route recovery's authored declaration failure through its existing RecoveryFailedError boundary after committed recovery. Do not change generic storage/input/root-path errors or authorize any mutation; only the canonical typed declaration failure can use this operation boundary. A branch that merely forces a numeric exit or copies error text is not the proposal. The shared item adapter needs `crates/jit/src/commands/mod.rs` (outside the correction footprint); the early typed composition belongs to already-authorized `dispatch/mod.rs` and/or `commands/bootstrap.rs`. Existing `errors.rs::RecoveryFailedError` is the reusable type; no second recovery parser or error vocabulary is needed. All failure registry assertions remain unchanged.

For worktree exec under A, keep its pending-record refusal in its actual command owner rather than catching and relabeling RetryableConflict. It needs only selected data and the repository lock, not declarations or code authority. Factor its existing lock/pending/child operation into a data-only command entry, selected by dispatch before code-root bootstrap; preserve discovery, initialized-store checks for a clean store, its under-lock pending refusal, child streams/status and caller cwd. It must not recover the record or invent a code root. New owners would be `crates/jit/src/commands/worktree.rs`, `crates/jit/src/dispatch/worktree.rs` and the export owner `crates/jit/src/commands/mod.rs`; `dispatch/mod.rs`, bootstrap and JSON admission are already in scope. Exact additional production owners for A together: **three files**, commands/mod.rs, commands/worktree.rs, dispatch/worktree.rs. No existing test assertion needs alteration. This is a material command-preparation route requiring acceptance; it is not silently authorized by the config-validation route.

**B. Accept a canonical early-bootstrap contract cutover.** Required-root declaration failures remain canonical PARSE_ERROR before command execution, including item list/search and recover; every command that reaches the common lock-free selection read returns RETRYABLE_CONFLICT on pending redo, including worktree exec. The later operation's existing error adapter still applies when an explicit valid env root lets that operation begin; this phase distinction must be explicitly accepted and documented, not left accidental. Preserve config validate's always-data-only findings route and preserve original committed recovery before new-work selection. Exact additional maintained owners for this cutover: `crates/jit/tests/cli_issue/failure_lever_registry.toml` (three changed expected classifications), `crates/jit/tests/cli_repo_workflow/worktree_exec_tests.rs` (pending bootstrap contract, still asserting no child and unchanged record), and `docs/reference/cli-commands.md` (canonical CLI preflight-versus-operation explanation, citing rather than copying code tables). Generated exit-code facts need no change: parse and retryable conflict are already universal codes. The record-path assertion also needs an explicit ruling: preserve path detail by enriching the canonical conflict context, or accept the common retryable diagnostic text. No such assertion or contract change is authorized by the present cycle3 brief.

Recommendation: **A** if preserving the existing requested error/report boundaries remains the priority; it avoids a phase-dependent public code change. B is a plausible greenfield cutover only after an explicit steward ruling. Neither may use a fabricated default root, silent error-to-absence fallback, private parser, config-postimage policy or pending-record replay from a reader.

## 3. Two release tests have no acting identity

`fast_issue/mutation_result_tests.rs:52–65` and `fast_issue/test_no_coordinator.rs:12–63` use `TestHarness::new()` and call issue release without supplying any acting identity. `TestHarness` constructs an in-memory executor; `commands/mod.rs:2561–2579` gives it undiscovered non-Git paths. Release calls `resolve_release_actor` (`commands/mod.rs:3059`, `commands/claim.rs:272–285`), which needs an explicitly configured agent or a supplied Git checkout identity. The claim assignee is not the actor who releases it. These identity-resolution owners and the fixture constructors are unchanged by the cycle3 diff (and no claim/mod source change appears between the original a9bda665 base and current HEAD). The failures are latent test independence concerns exposed by the complete target run; no baseline execution is claimed.

Do not set JIT_AGENT_ID for the test process, borrow host identity, weaken attributable release, or turn the no-coordinator scenario into a Git/coordinator scenario merely to make it pass.

Recommended explicit-input option: expose an issue-release entry accepting the existing Assignee acting identity, keeping one existing lifecycle release producer. The existing convenience release API resolves invocation identity then delegates; the two tests use the explicit entry and retain their persisted-result/lifecycle assertions. Exact additional owners: `crates/jit/src/commands/issue.rs` (facade), `crates/jit/src/commands/mod.rs` (same producer accepts explicit actor), `crates/jit/tests/fast_issue/mutation_result_tests.rs`, and `crates/jit/tests/fast_issue/test_no_coordinator.rs`. No new fixture/parser or process-global state is required. This is an API/scope decision outside the ten-file correction, not an attempted fix.

Alternative: a shared explicit actor provider for harness executors, which would additionally require `crates/jit/src/test_harness.rs` and would have to be justified as a production capability rather than a test-only bypass. It is a larger change than the explicit operation input and is not recommended here.

## Requested ruling

Authorize the in-footprint I/O source repair; choose A versus B (or a separately reviewed replacement) for the pre-root command boundaries; decide whether the explicit-actor release scope belongs in this issue or a separately owned correction. All source remains frozen pending that ruling. No further retry/cycle is assumed. The complete cycle3 result, cumulative findings and check history are in `5046408a-rework-3-result.md`.

# Explicit issue-release actor — standalone task proposal

Status: proposal only; no issue created, dispatched, implemented or committed. Steward requested this concern be separated from504. Proposed placement is one bounded corrective task under the existing Git CLI epic `f4d9502a`, **outside its53-node manifest and with no epic REQ coverage credit**. The four-file correction below must be accepted and assigned separately;504 source remains frozen and includes no actor API edit.

## Reproduced baseline

Both existing tests fail individually on unchanged main HEAD `f64105f313d55b83b8832b1d67f2cd30d31cb9fd`:

- `cargo test -p jit --test contracts --no-fail-fast fast_issue::mutation_result_tests::test_release_issue_returns_updated_issue -- --exact`
- `cargo test -p jit --test contracts --no-fail-fast fast_issue::test_no_coordinator::test_issue_lifecycle_works_without_coordinator -- --exact`

Each collected result is0passed/1failed with `Cannot release: no acting identity for the audit trail`, at the existing unwrap on lines64/62 respectively. Logs: `5046408a-actor-baseline-main-release-result.log` and `5046408a-actor-baseline-main-no-coordinator.log`. The machine record is `5046408a-actor-baseline-main.json`.

Main status was clean before and after; HEAD stayed exact. The source/index fingerprint stayed `b667e44cfa3d536b8ae54aace1db62372bf2474a7a463a7b999ffb86dcd154ee`; no source worktree diff. Main alone used `/mnt/nvme/jit/target`. The checks held the standard turnstile/shared-CI locks, disabled sccache/incremental/network, left RUSTC_WRAPPER empty and created/trap-cleaned a short owned TMPDIR in the same escalation namespace. Actor inputs were sanitized only in the child process: every JIT_* variable removed, empty owned XDG_CONFIG_HOME, GIT_CONFIG_GLOBAL=/dev/null and GIT_CONFIG_NOSYSTEM=1. HOME was unchanged. No ambient identity was supplied or installed.

For a matched comparison, the already-built frozen worker contracts binary ran those same two exact tests with the same sanitized actor inputs; both fail identically. No worker build or main/worker target mixing occurred. `5046408a-actor-baseline-worker.json` and its two logs record the worker target, HEAD and unchanged504diff hash. `5046408a-actor-source-audit.json` proves the two failing tests, issue facade/producer, claim actor resolver, agent resolver and shared harness files are byte-identical on main and worker. Thus this is a reproducible main concern, not an inference from the split-root worktree alone.

## Existing explicit-input audit

| Existing surface | Observation and suitability |
|---|---|
| `IssueOps::release_issue`, commands/issue.rs1147 | Takes only IssueIdPrefix and reason. Resolves the issue prefix before calling the release producer. No actor parameter. |
| `publish_captured_release`, commands/mod.rs3055 | Resolves the ambient actor, then calls the canonical lifecycle producer with CapturedLifecycleMutation::Release. No supplied actor is accepted at this facade/producer boundary. |
| `CapturedLifecycleMutation::Release`, commands/mod.rs1021; event construction3380 | Already carries the canonical Assignee `released_by` independently of the former assignee. The storage/domain publication mechanism needs no change. |
| `resolve_release_actor`, commands/claim.rs272 | Uses explicit agent configuration/environment, then supplied checkout Git identity. It never invents an actor. Keep this existing convenience resolution unchanged. |
| `resolve_agent_id_with`, agent_config.rs100 | Already supports injected lookup/config functions for testing the generic identity resolver, but issue release does not expose a way to pass those inputs. Reusing its tests does not supply an actor to the release operation. |
| `ClaimOps::release_by_issue_with_actor`, commands/claim.rs310 | Private callback injection for **lease eviction**, exercised by a module-local fixture at756. Different operation/audit path; it is not an issue-release interface and must not be reused as a bypass. |
| `TestHarness::new/rooted_at`, test_harness.rs55/64 | Reuses the shared in-memory executor fixture; no actor injection. Its synthetic non-Git paths deliberately provide no Git identity. |
| `CommandExecutor::with_worktree_paths`, commands/mod.rs2549 | Explicit authority injection for real data/coordination paths, not an actor setter. Inventing Git authority or changing the no-coordinator fixture to a Git/coordinator scenario would avoid the property being tested. |

No applicable existing explicit issue-release actor input was found. No new ambient/test-only provider is proposed.

## Proposed issue title

Allow an explicit acting identity for issue release

## Proposed issue description

Issue release requires an attributable actor, but its library facade only resolves that identity from invocation configuration or Git. Add an explicit typed actor input so isolated callers can release issues without ambient identity, while keeping the existing convenience API and one publication computation.

## Background

The existing in-memory release-result and no-coordinator lifecycle tests provide a claim assignee but no release actor. Those are separate identities: a person or agent may release someone else's claim, and the audit must record who performed the release. Both tests fail on unchanged main when agent environment/configuration and ambient Git identity are unavailable.

## Success Criteria

- [hard] REQ-01: An issue-release facade accepting the canonical Assignee actor releases a claimed issue without resolving environment, user configuration or Git identity, returns the persisted Issue and records the supplied actor independently of the former assignee.
- [hard] REQ-02: Existing convenience release retains its issue-prefix lookup and validation/error precedence, resolves invocation identity only after that existing lookup, and publishes through the same captured lifecycle release producer. A missing issue still fails before actor resolution; absent acting identity still fails without publishing, rather than becoming an anonymous/default actor.
- [hard] REQ-03: Release keeps its current reason, previous-assignee and acting-identity audit data, issue transition/no-op behavior, coupled publication and failure atomicity. Explicit and convenience callers use one release producer, with no alternate mutation or event path.
- [hard] REQ-04: The existing release-result and no-coordinator lifecycle scenarios pass alone and together under sanitized actor inputs, preserving their persisted-result and cleared-assignee assertions. Tests use explicit operation inputs and owned shared fixtures, without process-wide environment/cwd mutation, a fake Git authority or a test-only actor provider.

## Notes

Use the existing canonical Assignee type and captured lifecycle Release request. This is an input capability of the command facade; no new CLI flag, actor vocabulary, identity-resolution priority, storage format, Git floor, coordination backend or actor-setting mechanism is required.

The description above is standalone proposed issue content; this proposal does not create tracker content.

## Exact four-file implementation plan

1. `crates/jit/src/commands/issue.rs`: add the explicit Assignee release entry, e.g. `release_issue_as(prefix, reason, actor)`. Keep the existing convenience entry's argument order and observable lookup/identity precedence. Both resolve the prefix in the existing owner before reaching the same producer.
2. `crates/jit/src/commands/mod.rs`: change the existing private `publish_captured_release` input to accept the already-selected Assignee. Remove its ambient resolution after moving that resolution to the convenience facade at the same logical point. Keep the CapturedLifecycleMutation::Release request and entire captured publication/event logic unchanged.
3. `crates/jit/tests/fast_issue/mutation_result_tests.rs`: supply an explicit actor through the new facade in the existing release test; retain the persisted-result assertion. In this same owning file, verify that the release event's actor is the supplied actor (use an actor different from the previous claim assignee), and cover the convenience facade's lookup-before-identity error relationship without changing process state.
4. `crates/jit/tests/fast_issue/test_no_coordinator.rs`: supply the actor explicitly at the existing release call. Preserve the no-coordinator/in-memory fixture and cleared-assignee assertion; do not add Git/config identity setup.

No edits to commands/claim.rs, agent_config.rs, test_harness.rs, dispatch, storage, event schema, CLI, Cargo targets, or504-specific source/tests. If the implementation discovers a necessary fifth owner, report the concrete reason before editing.

## Precise validation/error order

Preserve today's convenience flow: **resolve IssueIdPrefix through storage → require the existing worktree authority and resolve the acting identity → publish the captured Release request**. Do not implement convenience release as `release_issue_as(prefix, reason, resolve_actor()?)`, because argument evaluation would move the actor error ahead of the existing prefix lookup. Resolve the full issue ID first, then obtain the actor, then call the producer directly with both typed values.

The explicit facade follows **resolve prefix → publish with supplied Assignee**. It does not perform an ambient identity lookup at any point. Subsequent state validation, no-op behavior, lease/policy/session checks, coupled derived-state computation and event publication stay in the existing producer in their existing order. The old convenience method continues to require an attributable actor even where its later captured operation becomes a no-op; no eager shortcut is introduced. Neither caller substitutes the claim assignee as the release actor.

## Validation and proposed sequencing for approval

Retain the two baseline logs as actual RED. Run the new/updated owning cases under the same sanitized actor inputs individually, then the full contracts target without fail-fast, relevant existing release/identity command tests, formatting and all-target Clippy. Existing resolver priority and lease-eviction tests remain their current owner; do not duplicate them in this task. The responsible lead assigns configured gates/review through normal workflow after this proposal is accepted.

Proposed graph/sequencing, for lead/steward approval only:

- Create one new bounded corrective task under Git CLI epic `f4d9502a`, outside the53-node manifest; it claims no epic REQ coverage and does not amend the manifest count or coverage mapping.
- Make5046408a depend on that task if no existing transitive path already supplies the edge. This expresses the concrete integration prerequisite; no task/edge is created by this proposal.
- Keep504 frozen while the separate actor task is implemented, checked/reviewed and landed on main. Mainfix first prevents two writers from editing commands/mod.rs concurrently.
- Lead refreshes504 from the landed main actor fix, preserving its frozen diagnostics diff and resolving any actual conflict. Actor changes arrive by that refresh; they are not reimplemented or counted as504 scope.
- After the selected-A thirteen-file amendment has its fresh independent design review and explicit implementation dispatch, resume the bounded504 correction and rerun its combined CLI/contracts validation. The actor task does not reset504's rework limit or substitute for504's full gate/reviews.

No issue creation, dependency edit, dispatch, source edit, commit or merge is authorized or performed by this artifact.

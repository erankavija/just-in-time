# Git object framing and runtime proposal

**Decision requested:** approve Git 2.42 or newer for Git-backed features and the Docker runtime base change to Debian Trixie. The proposal remains isolated and is not approved for landing. Core issue tracking remains Git-optional.

## Concrete patch

[Reviewable patch](git-floor-decision.patch), based on main source `270f4894b8aa78ba6dfc696ec0bf6cd8bbd30c02`, proposal `43706d377ae940ac3d4962136b16d6a647f58c99`. Six source/document files, 255 insertions and 90 deletions; this includes the already-planned a273 committed-path consumer migration as well as its framing correction.

- `storage/git.rs`: the existing one-process object reader and presence batch use `cat-file -Z`; request/header/body separators are NUL, body bytes remain length-delimited. Valid LF-containing names work; NUL-containing input is rejected.
- `storage/json.rs`: the committed-path consumer uses that reader, preserves original revision-expression resolution before peeling a canonical object ID, and retains typed errors, binary bytes and one-process behavior.
- `git_module_tests.rs` and `repository_state_store_tests.rs`: owning protocol coverage and existing argv expectations reflect NUL framing.
- `INSTALL.md`: only the canonical optional Git dependency entry changes to Git >=2.42 for Git-backed features.
- `Dockerfile`: only runtime `FROM debian:bookworm-slim` changes to `debian:trixie-slim`. Existing Rust/Node builders, packages, topology and entrypoint are preserved.

Git 2.42 introduced output-and-input NUL framing (`-Z`): [upstream release notes](https://github.com/git/git/blob/v2.42.0/Documentation/RelNotes/2.42.0.txt). Actual Git 2.39.5 experiments show that its input-only `-z` cannot unambiguously frame all valid names and missing responses; the counterexample and transcripts are in [the investigation](object-framing-investigation.md). There is no compatibility shim, extra version probe, private parser or extra per-path process.

## Evidence

- Full Cargo gate `dfc80720-8f01-452a-a02f-594efd8d9d05` and independent review `9c0cec8f-58a6-4f86-b853-3f81672959c8` both stable PASS on `2e51395b46f00cf0ac77815300fd2651eba77d6d`; zero review findings. Prior F1 (valid LF committed path rejected) is closed. Gate evidence preserved in `cb9b43c78`.
- After composing the independently reviewed available-target gitlink correction, all six proposal files are byte-identical to that reviewed source: [exact proof](a273-corrected-asset-composition-proof.json). The 28 asset CLI tests pass with the proposed protocol, including both gitlink target cases and one-process batching: [log](a273-corrected-asset-composition-tests.log).
- Docker image built successfully and its server served embedded assets and a healthy response; actual runtime Git is 2.47.3: [build/smoke evidence](object-framing-docker-result.json).
- That immutable image then passed 12 incremental protocol assertions across both `-Z` modes: real LF filename, exact NUL/LF/non-UTF8 binary payload, missing LF/header-mimic names, both gitlink target cases, subsequent response alignment and clean exit: [runtime protocol report](object-framing-runtime-protocol-result.md).

## Limits and landing boundary

The Docker build precedes the final asset-consumer composition. The final composition is covered by the unchanged-six-file proof and focused tests; no post-composition Docker rebuild is claimed. Git 2.42 is the documented feature floor; actual executable checks used Git 2.47.3 and 2.56.0, with negative/ambiguity research on 2.39.5. Git 2.39 installations need a newer Git for Git-backed features under this proposal.

Approval covers the stated Git minimum and runtime base proposal. The separate 06177584/38df8a6c installation-policy holds remain in force. No image has been published. After approval, canonical main landing still requires its mandatory full merged Cargo gate before issue completion.

The separate snapshot resolve-commit expression issue is under shared-producer design review and is not silently accepted or implemented by this proposal.

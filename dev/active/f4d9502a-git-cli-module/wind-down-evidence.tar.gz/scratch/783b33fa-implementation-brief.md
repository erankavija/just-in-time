You are dispatched to JIT issue 783b33fa. Your worktree is at:
  /home/vkaskivuo/Projects/just-in-time/.agents/worktrees/agent-783b33fa
on branch worktree-agent-783b33fa, anchored to main at 2e1692cffc3eb439ccbeabe779086a74a60b2d6a.

Hard rules for path discipline (worktree-dispatch-protocol):
- Run every shell command from your worktree root. Prefix tool calls
  with 'cd /home/vkaskivuo/Projects/just-in-time/.agents/worktrees/agent-783b33fa && ...' if your
  shell state has drifted.
- Use only paths relative to the worktree root in your tool calls.
  Checkout-specific absolute paths are forbidden — they leak
  files into main's checkout.
- Before every build and test command, export TMPDIR="/tmp/lead-worker-tmp/home/vkaskivuo/Projects/just-in-time/agent-783b33fa".
- Never run 'git checkout', 'git switch', 'git worktree add/remove'.
- Commit on your worktree branch only. Do not push.
- Keep build/dependency caches at their in-worktree defaults; they may
  arrive pre-seeded warm. Never redirect one onto tmpfs.


# Approved overrides to generic header

Lead owns ALL Git commits/merges and tracker/gate/lifecycle mutations; do not commit. The generic long TMPDIR is superseded by steward's short owned /dev/shm directory created and trap-cleaned in the SAME escalated command namespace for each build/check batch. Source/caches/targets stay on disk in this worktree. Scratch report/log files under /tmp/f4d9502a-lead are allowed; never write main or peer source. Tool workdir must be this isolated worktree. Use sandbox escalation as necessary for authorized writes/builds in its NVMe location. No subagents.

# Issue

Title: Allow an explicit acting identity for issue release
ID:783b33fa-6fdf-4cf4-a9f2-323a90c27734
State:in_progress, assigned/leased agent:f4d9502a-lead. No unmet dependencies. Gates:cargo-ci and code-review (lead evaluates after your frozen result). Steward approves exact four files and Sol/high; temporary fourth tree approved.504 source is frozen, so only you implement source now.

Issue release requires an attributable actor, but its library facade only resolves that identity from invocation configuration or Git. Add an explicit typed actor input so isolated callers can release issues without ambient identity, while keeping the existing convenience API and one publication computation.

## Background

The existing in-memory release-result and no-coordinator lifecycle tests provide a claim assignee but no release actor. Those are separate identities: a person or agent may release someone else's claim, and the audit must record who performed the release. Both tests fail on unchanged main when agent environment/configuration and ambient Git identity are unavailable.

## Success Criteria

- [hard] REQ-01: An issue-release facade accepting the canonical Assignee actor releases a claimed issue without resolving environment, user configuration or Git identity, returns the persisted Issue and records the supplied actor independently of the former assignee.
- [hard] REQ-02: Existing convenience release retains its issue-prefix lookup and validation/error precedence, resolves invocation identity only after that existing lookup, and publishes through the same captured lifecycle release producer. A missing issue still fails before actor resolution; absent acting identity still fails without publishing, rather than becoming an anonymous/default actor.
- [hard] REQ-03: Release keeps its current reason, previous-assignee and acting-identity audit data, issue transition/no-op behavior, coupled publication and failure atomicity. Explicit and convenience callers use one release producer, with no alternate mutation or event path.
- [hard] REQ-04: The existing release-result and no-coordinator lifecycle scenarios pass alone and together under sanitized actor inputs, preserving their persisted-result and cleared-assignee assertions. Tests use explicit operation inputs and owned shared fixtures, without process-wide environment/cwd mutation, a fake Git authority or a test-only actor provider.

## Notes

Use the existing canonical Assignee type and captured lifecycle Release request. This is an input capability of the command facade; no new CLI flag, actor vocabulary, identity-resolution priority, storage format, Git floor, coordination backend or actor-setting mechanism is required.

# Scope and method

Read AGENTS.md, dev/TESTING.md, linked dev/active/783b33fa/plan.md and relevant owners. Resolve its actual requirement/item citations with jit item show. Scope EXACTLY:
- crates/jit/src/commands/issue.rs
- crates/jit/src/commands/mod.rs
- crates/jit/tests/fast_issue/mutation_result_tests.rs
- crates/jit/tests/fast_issue/test_no_coordinator.rs
A fifth owner or material design gap requires evidence/lead approval BEFORE editing. No CLIflag, actorvocabulary/provider, storage/domain/event path, testfixture Git setup, newtarget, resolverpriority or ambient identity workaround. Do not edit commands/claim.rs, agent_config.rs, test_harness.rs or any504 source/plan.

Implement the accepted explicit canonical Assignee facade, e.g.release_issue_as(prefix,reason,actor), and let existing convenience release retain prefix lookup BEFORE invocation actor resolution. Never write release_issue_as(prefix,reason,resolve_actor()?) which evaluates identity too early. Both use ONE existing captured lifecycle producer; move only selected actor input, keep request/publication/state/no-op/audit behavior. Supplied actor must differ from previous assignee in owning audit test. Preserve existing persisted-result and no-coordinator/cleared-assignee assertions. New criteria do not require re-proving existing mutation crash/resolver matrices; only new input/wiring properties belong here.

Test first: original genuine RED on unchanged mainf64105f31 is /tmp/f4d9502a-lead/5046408a-actor-baseline-main.json + two logs; matched frozen worker proof/7-file source audit also there. Read full /tmp/f4d9502a-lead/5046408a-actor-task-proposal.md for accepted details; its proposal-only status is historical, superseded by this dispatch/linkedplan/steward acceptance. Add meaningful new facade/audit/precedence test(s), obtain RED, then implement. Existing tests must pass alone and together with sanitized CHILD-process inputs: remove all JIT_* variables, use owned empty XDG_CONFIG_HOME, GIT_CONFIG_GLOBAL=/dev/null, GIT_CONFIG_NOSYSTEM=1; HOME unchanged. Do not mutate process-global env/cwd inside tests. No ambient identity may mask a failure.

Validation: affected cases alone and together under same sanitized actor inputs, full contracts target without fail-fast, relevant existing release/identity owning tests, cargo fmt --all -- --check and cargo clippy --workspace --all-targets zero warnings. Lead then runs actual configured full Cargo, configured code-review and merged gate; do NOT evaluate/pass gates yourself. Preserve all failures/reruns and clarify overlapping filter counts. A test harness command failure is not permission to change assertions or widen scope.

# Resource/check protocol

Before build/check, ensure /tmp has>=4GiB and>=20%freeinodes; keep all targets/caches in this worktree on disk. Use turnstile then shared CI lock for focused checks:
flock -o /tmp/jit-ci-turnstile.lock flock -o -s /tmp/jit-full-ci.lock <your check batch>
Set CARGO_INCREMENTAL=0,CARGO_CI_NO_SCCACHE=1,CARGO_NET_OFFLINE=true,RUSTC_WRAPPER empty. Create short owned /dev/shm TMPDIR and cleanup trap within the same escalated shell command; no long Unix-socket TMPDIR. One batch at a time, edits paused until every started check is collected; never cancel a queued run. Use non-short-circuiting result collection for independent validation so failures do not hide siblings. Never clean another tree/target or mix main target; seeded dependency caches previously produced E0463/E0460, which must be reported/preserved and repaired only in OWN disposable target. If workspace Clippy needs missing generated web assets/dependencies, report concrete setup gap before touching source or copying main assets. No network/publishing/package-policy changes.

# Return deliverable

Write /tmp/f4d9502a-lead/783b33fa-result.md with four criterion evidence at actual lines, exact changed files, actualRED and all failed/rerun checks, source HEAD+binarydiff SHA256, no-active-command/frozen confirmation. No source edits after frozen return. Lead owns tracker, durablelinks, commits, source refresh and ready-only landing. Report any new material gap before edits. Do not stop after acknowledging capability; implement within accepted scope through checks.

## Return

Your final message is the dispatcher's only input; write it for the next action.
Use these sections in order and write `None.` for an empty one:

1. **Outcome** — `done`, `partial`, or `blocked`, then the deliverables your
   assignment names (artifact paths, commit SHAs, counts, verdict).
2. **Needs decision** — each choice, escalation, or conflict the dispatcher must
   resolve, with the options and your recommendation.
3. **Deviations** — each departure from the assignment, each unmet criterion, and
   each failed or skipped check with its command and first failing line.

Omit passing checks, step narration, restated instructions, and anything the
written artifact or commit already records. Stay within 200 words unless a
deviation needs more evidence.

Deliver the message through the reporting channel the dispatch names. When the
harness hides a background agent's final output from its dispatcher, send it
with the harness messaging tool.

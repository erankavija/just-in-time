# 5046408a selected-A boundary amendment — proposal for bounded design review

Status: **proposal/read-only**. Steward selected A: preserve the shared typed item/recover adapters, and give worktree exec a data-only entry that preserves its own under-lock pending-record refusal. The I/O-source repair is in scope. The exact proposed correction footprint is thirteen files: the accepted ten plus commands/mod.rs, commands/worktree.rs and dispatch/worktree.rs. Fresh independent bounded design review is required before edits. B and registry/contract cutover are not selected; no retry counter is reset. The original alternatives and failure history remain in `5046408a-rework-3-boundary-proposal-before-A.md` and `5046408a-rework-3-result.md`.

504 source remains frozen at HEAD `376978ed05c011717ab7c2d88fab54954f045f15`, diff SHA256 `f0c5fd8a3e18932804cd4f02b412b9d1540321d408522733e66601a7ce22b9a3`. No production source, test assertion, registry, tracker or main source was edited for this revision.

## Proven failures and exhaustive registry scope

The complete non-fail-fast run collected CLI1222pass/3fail and contracts548pass/2fail; formatting and all-target Clippy passed. Logs and all intermediate RED/compile corrections remain in the cycle3 result. The nine applicable failure-registry arms were selected directly from their setup declarations and independently reproduced in `5046408a-rework-3-full-boundary-registry.json`:

| Arm/setup | Required result | Current result |
|---|---|---|
| config show / malformed config | PARSE_ERROR | Matches |
| config validate / malformed config | VALIDATION_FAILED findings | Matches |
| config show-hierarchy / malformed config | PARSE_ERROR | Matches |
| doc conformance / malformed config | PARSE_ERROR | Matches |
| issue list / pending redo | RETRYABLE_CONFLICT | Matches |
| item list / malformed config | INVALID_ARGUMENT | PARSE_ERROR |
| item search / malformed config | INVALID_ARGUMENT | PARSE_ERROR |
| label namespaces / malformed config | PARSE_ERROR | Matches |
| recover / malformed config | recovery_failed | PARSE_ERROR |

The universal retryable-read projection also passed its eleven commands in both human and JSON forms. Separately, the existing worktree-exec pending test requires GenericError, the record path and recovery guidance, no child invocation and unchanged record bytes; bootstrap currently returns RetryableConflict first. All these registry/projection/exec assertions remain unchanged under selected A.

The two actor failures are now reproduced on unchanged main under sanitized inputs. They are excluded from this amendment and have their own proposed task; see `5046408a-actor-task-proposal.md` and `5046408a-actor-baseline-main.json`.

## Shared typed error adapters

One canonical syntax document and typed required WorktreeConfig projection remain unchanged. A failure to parse a required declared root is not evidence of absence and never chooses a default code directory. D27 still applies the old committed record before projecting recovered declarations for new work.

1. Extract the existing `CommandExecutor::cached_config` argument-error computation in commands/mod.rs into one crate-visible command-owned helper, `configuration_argument_error(error: impl Display) -> InvalidArgumentError`. Its output remains the existing InvalidArgumentError with the existing `invalid .jit/config.toml: ...` context. The cached full-view consumer and the item invocation's early required-declaration failure call this same helper; no copied formatter, numeric exit mapping or parser.
2. At the CLI bootstrap composition boundary, adapt only a **typed canonical ConfigurationAssemblyError originating from the required projection**, for the item command family. Use a direct `anyhow::Error::downcast::<ConfigurationAssemblyError>()` on the failure returned by ordinary `open_repository`, whose direct authored-assembly failures are the required WorktreeConfig projections. On failed downcast, return the original error unchanged. Do not search arbitrary nested error chains or reinterpret anything resembling configuration text. A private dispatch adapter selects the item helper for Commands::Item, the existing RecoveryFailedError constructor for Commands::Recover, and preserves the canonical typed error for every other command; it does not match or manufacture an exit code. The command layer owns argument semantics; dispatch selects the relevant operation boundary and remains responsible for routing, not parsing.
3. For recover, route the same authored projection failure through the existing RecoveryFailedError type after committed recovery. This is the same typed recovery adapter already used by the operation and existing startup redo failure handling. Required policy still uses original recovered declarations even with an explicit override. Do not wrap explicit root-path errors, unsafe data capabilities, unsupported indexes, permission failures or retryable admission errors as authored declaration failures.
4. Ordinary operations retain canonical parser failures. Config validate retains its separately admitted data-only report and registered findings path. An env-selected root still makes only the declared root projection unnecessary; full consuming operations retain their own canonical validation/error adapter. The shared item adapter makes item classification agree across those routes.

This changes the early composition point while preserving the existing operation's typed error result. It is not a catch that assigns an exit number, a broad fallback, or an attempt to run a command against an invented layout. After an early failure, no executor/code authority is constructed and no new mutation is authorized.

## Data-only worktree exec: one command computation

The existing operation only acquires the repository lock, refuses a pending record and launches a child; it does not use a code layout. The sole in-tree caller of `WorktreeOps::exec` is dispatch/worktree.rs. Replace/extract that operation into one command-owned data-only entry in commands/worktree.rs. Do not retain a second lock/pending/child implementation or a compatibility alias around a fake layout. Any normal group handler retained for registration delegates to the same data-only operation using its actual JsonFileStorage; the CLI data-only route reaches that operation directly.

A small context carries the selected JsonFileStorage/data path and captured invocation cwd, without a CommandExecutor, WorktreePaths, code root, Git probe or mutation guard. It can be created from RepositoryInvocation by the command owner using the existing selected-data discovery helper. The narrow bootstrap result carries this context for WorktreeCommands::Exec; other worktree commands still use ordinary bootstrap. The registered worktree_exec leaf, existing WorktreeExecResponse and Outcome::Exited remain the output owner; both adapters share the same child-status outcome computation and registered-leaf admission before the common emitter. No command/schema leaf is added.

### Exact order and error precedence

1. **Invocation inputs/discovery:** capture cwd and data override once, and perform the existing global write-policy-token validation before repository work. Select the data path through the existing JIT_DATA_DIR/upward-discovery logic. Do not load configuration, derive a default code root or select a code checkout. The wrapper consumes only data location and caller cwd; a code-root setting has no role in where this child runs. It remains in the inherited child environment for a child JIT invocation to interpret. The wrapper does not authorize a JIT mutation through linked-write policy; each child JIT mutation keeps its own recovery/selection/policy boundary.
2. **Root capability precheck:** prove that the selected data directory exists and is safe through the shared storage-owned no-follow root-capability primitives. No index, config, event log or redo contents are read at this stage, and no root or parent directory is created. Missing data gives the existing RepositoryNotFoundError; unsafe/unreadable roots retain their typed failure. If exposing this root-only probe requires factoring DataReadSession's opening step, retain its single missing-ancestry owner and published-ancestor guard rather than inventing another absence protocol. The probe establishes no code authority.
3. **Acquire the existing lock chain:** call the canonical JsonFileStorage/IssueStore repository-lock acquisition. It already holds data-bootstrap before repo-write and applies JIT_LOCK_TIMEOUT; no worktree/event lock, new ordering, retained mutation session or recovery session is introduced. A timeout remains LockTimeout and no child starts. This command intentionally waits because its explicit job is executing under a writer mutex.
4. **Pending record first under the held lock:** invoke the command-owned record-presence refusal before reading/validating index contents. A present regular redo record, including the existing test's malformed `leftover` bytes, returns the existing GenericError message naming the absolute record path and `jit recover`. The record is not parsed, replayed, replaced or removed; no declaration/index/event materialization runs. Storage presence/capability failures remain typed errors. Use the existing storage no-follow capability owner for any bounded presence inspection that is needed; do not implement a private redo parser. In particular, do not catch RetryableConflict from an attempted read and relabel it as this refusal.
5. **Clean-store initialized validation under that same guard:** after absence is established, use JsonFileStorage's shared data-only index validation/admission. Missing index, malformed/unsupported index, permission errors and unsafe entries remain their existing typed storage/format failures. No declaration assembly is needed. A missing or invalid index never launches the child. If a non-cooperating external change produces RetryableConflict at this stage, propagate it as RetryableConflict; it is not the pending-refusal branch. The normal producer lock protocol prevents a cooperative writer from publishing between steps4 and5.
6. **Child:** only after clean initialized validation, run the exact program/argv with `current_dir` set to the cwd captured at invocation. JIT_DATA_DIR selects the protected data, not the child cwd; neither configured nor environment-selected code roots replace the caller cwd. Inherit stdin, stdout, stderr and environment. Wait for child completion while retaining the same lock guard. Return its integer status unchanged; retain the current generic fallback when ExitStatus has no numeric code. A spawn failure is the existing wrapper GenericError.
7. **Cleanup/rendering:** every return path drops the RAII guard, including pending refusal, initialized validation failure, spawn error and any child status. The predecessor guard stays held until the repository guard releases. No manual lock-file deletion, fresh lock protocol, process-global cwd/environment mutation or root publication is added. Existing ignored lock files may persist as they already do; cleanup means releasing the held locks, not deleting lock namespace entries. Only wrapper errors receive JIT's human/JSON error rendering. Child bytes are not wrapped, summarized or emitted a second time.

Ordering is deliberate: absent/unsafe data fails before acquisition; an occupied lock can time out before pending inspection; after acquisition a pending record outranks invalid/missing index or malformed configuration; only a clean store reaches initialized validation. A clean but uninitialized store may acquire/release the existing lock files, but publishes no repository content and starts no child.

### D25 and the boundary of this exception

Worktree exec is an explicit mutex/child operation, not an ordinary repository read. Its intentional bounded wait is the documented operation. No ordinary reader is redirected through it: config validate, item reads, issue reads and every other lock-free capture retain DataReadSession admission, bounded RetryableConflict, no writer lock and no replay. A child JIT read remains lock-free and succeeds on an otherwise clean store even while the parent holds its mutex; a child JIT mutation waits on that same lock and fails with the existing bounded LockTimeout. The current owning CLI tests already assert both behaviors.

D26/D27 recovery mechanisms and original audit bytes are unchanged. Exec never invokes recovery; only explicit recover/mutation openings apply committed records, and they continue using the original recorded root before selecting new work.

## I/O source preservation

Change only the canonical RepositoryStateStoreError::Io wrapper so its concrete std::io::Error is retained in the source chain (`#[error("{0}")]` with the existing from/source relationship). The shared classifier already owns permission-to-code mapping. Add the owning chain assertion in repository_state_store_tests.rs and rerun the unchanged permission projection. Do not add a classifier special case or weaken the projection.

## Exact thirteen-file footprint and ownership

| File | Responsibility in combined correction |
|---|---|
| crates/jit/src/declarations/mod.rs | Existing canonical syntax/full/projection computation and owning tests |
| crates/jit/src/config.rs | Canonical full-view integration |
| crates/jit/src/storage/repository_state_store.rs | Existing admitted observations, shared root-capability/absence owner if needed by exec, I/O source preservation |
| crates/jit/src/storage/repository_state_store_tests.rs | Existing observation migration/composition and I/O-source owner |
| crates/jit/src/storage/json.rs | Shared data-only root/initialized index checks; no code layout or recovery for exec |
| crates/jit/src/commands/bootstrap.rs | Shared data discovery, required projections and explicit-root validation; recovery order unchanged |
| crates/jit/src/dispatch/mod.rs | Typed operation-error composition and explicit data-only exec context routing |
| crates/jit/src/commands/config.rs | Existing single data-only diagnostic report computation |
| crates/jit/src/dispatch/config.rs | Existing canonical diagnostic outcome/registered findings admission |
| crates/jit/tests/cli_repo_workflow/project_config_tests.rs | Existing diagnostic boundary tests; all original assertions retained |
| **crates/jit/src/commands/mod.rs** | Shared existing item configuration-error adapter, with no actor-API change in504 |
| **crates/jit/src/commands/worktree.rs** | Single data-only exec computation and cheapest owning tests for new ordering/wiring |
| **crates/jit/src/dispatch/worktree.rs** | Shared registered exec outcome/status adapter |

No edit to failure_lever_registry.toml, worktree_exec_tests.rs, output/error taxonomy, generated facts, docs, actor files, main.rs, cli.rs, storage/mod.rs, repo_lock.rs or a new Cargo target. The old worktree-exec CLI owner is run unchanged. If the implementation cannot preserve these contracts inside this exact footprint, report the concrete gap before editing.

## Bounded validation and review conditions

- Owning storage test proves I/O-source preservation; unchanged permission-denied exit projection proves the public boundary.
- Shared adapter owner tests compare early typed declaration failure and existing item full-view error computation without duplicating parser matrices. Run the complete unchanged failure-envelope corpus, including all nine applicable registry arms, so item search/recover cannot hide behind item list's first assertion.
- Commands/worktree.rs owns additional composition tests using existing fixtures: selected data is independent of child cwd; no code/Git requirement; clean missing/invalid index never runs the child; pending-plus-invalid-index refuses pending without replay; a return/spawn error releases the lock so a later acquisition succeeds. Use the cheapest existing layer and no global cwd/env mutation or fixed path. Existing CLI worktree-exec tests continue to own child status, child read/mutation behavior, lock timeout and unchanged pending refusal assertions.
- Retain existing config report/repair, all observation/rework1, D25/D26/D27 and policy tests; run affected owners and full CLI/contracts without fail-fast after implementation, then fmt and all-target Clippy. The separate actor fix should land on main and be refreshed into504 first so full contracts are not masked by ambient identity.
- Fresh bounded independent design review evaluates this exact selected-A ordering/footprint before any edits. Lead owns subsequent source integration, configured full gate and implementation reviews. This proposal grants no new retry cycle.

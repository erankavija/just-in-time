# 5046408a correction cycle3 — partial implementation, new boundary decision required

**Status: partial / blocked on steward boundary and footprint ruling. Source frozen; no active command.** Accepted diagnostics R2 and ten-file correction are implemented. Their original malformed-config report and invalid-preimage repair regressions now pass unchanged. Full CLI/contracts investigation exposed additional existing boundary/fixture failures; they are not hidden, fixed by assertion changes, or declared out of scope without decision. No configured gate or implementation review was run by the worker.

HEAD: `376978ed05c011717ab7c2d88fab54954f045f15`. SHA256 of `git diff --binary`: `f0c5fd8a3e18932804cd4f02b412b9d1540321d408522733e66601a7ce22b9a3`. No source edit followed the collected final batch. No tracker, commit, merge, install, gate, main-source or peer-tree operation occurred. The steward's single extra cycle3 authorization is not treated as a reset or permission for further cycles.

Decision artifact: `/tmp/f4d9502a-lead/5046408a-rework-3-boundary-proposal.md`. It gives complete registry evidence, preserves the current assertions, identifies an in-footprint I/O-source repair, contrasts shared existing operation adapters/data-only exec with an explicitly authorized bootstrap-contract cutover, and specifies an explicit-actor release correction outside the current scope. No proposal change is implemented.

## Exact implemented footprint

Only the accepted ten files differ from HEAD:

1. `crates/jit/src/declarations/mod.rs`
2. `crates/jit/src/config.rs`
3. `crates/jit/src/storage/repository_state_store.rs`
4. `crates/jit/src/storage/repository_state_store_tests.rs`
5. `crates/jit/src/storage/json.rs`
6. `crates/jit/src/commands/bootstrap.rs`
7. `crates/jit/src/dispatch/mod.rs`
8. `crates/jit/src/commands/config.rs`
9. `crates/jit/src/dispatch/config.rs`
10. `crates/jit/tests/cli_repo_workflow/project_config_tests.rs`

No new source file or Cargo target. Existing project-config and exit-projection assertions are unchanged. The original observation fixture/accesses were mechanically migrated to canonical full/projection APIs while preserving all absence/publication/replacement/admission assertions. Existing JSON index-loader assertions are also unchanged. Canonical storage/deployment docs are unchanged from the earlier implementation; the settings, code/data authority and D26/D27 public contracts remain the same. Newly exposed preflight-versus-operation error semantics require the separate ruling, not an unreviewed documentation rewrite.

## Implemented correction and evidence

- D20: `declarations/mod.rs:22–112` owns one parsed syntax document; canonical JitConfig assembly and required WorktreeConfig projections are views over it. Fields are selected before canonical deserialization. No default/partial JitConfig or second parser in bootstrap/commands. Pure projection tests at213/225/237 cover unrelated invalid fields, overridden root, original policy and malformed-versus-unneeded syntax.
- `storage/repository_state_store.rs:541–633` retains admitted raw declarations/root/commit evidence and a parsed document without eager full assembly. Initialized diagnostics capture index and all three declaration sources before one admission. Composition test3314 crosses a committed index/config publication and discards the stale index error rather than mixing captures.
- `storage/json.rs:409–434,796–799,842–860` shares captured index validation with ordinary initialized-store checks. The existing production index loader now uses the same data-only admission owner; no parallel absence fallback.
- `commands/bootstrap.rs:94–148` retains committed recovery first, then projects only effective root and governed original policy. Override does not excuse invalid original linked policy. Shared explicit root validation238 preserves raw-component no-follow checks, overlap and typed setting/path errors. New owning bootstrap cases442/468 pass; original D27 audit/recovery matrix536 passes.
- `commands/config.rs:74–112` is the single data-only diagnostic computation, with storage/index/admission errors outside authored findings. Config absent still assembles siblings; explicit env path validation precedes authored findings after admission. Invocation inputs are captured once in `dispatch/mod.rs:141–156`; report construction rereads no environment.
- `dispatch/mod.rs:123–159,185–192` carries a report without constructing a code executor. `dispatch/config.rs:40–73` shares the existing outcome and calls registered `config_validate` leaf admission before the common emitter. Existing plain stdout/stderr, JSON details and exit4 assertions all pass.
- Existing edited-document/postimage/derived publication remains at `commands/config.rs:235,368`; the formerly blocked valid-name repair passes at `project_config_tests.rs:421` without authorizing from proposed config.

## Preserved failure history and actual collected checks

All logs below are under `/tmp/f4d9502a-lead/`. Complete earlier histories remain in `5046408a-implementation-result.md`, `5046408a-rework-1-result.md` and `5046408a-rework-2-result.md`; none is overwritten. This includes original test-first failures, compile/check corrections, generated-cache E0463/E0460 failures and repair, the first full-gate absent/synthetic-config regression, and rework1's deterministic published-ancestor RED/fix. Gate1 evidence was committed at2fb068c61; the shared rework1 correction70e934693 passed its owners and gate2 cleared those workflows/all25doctests. Gate2 then failed after3386pass/1fail with1712notrun; its evidence is current376978ed0 and `5046408a-cargo-ci.json`.

The previous genuine unchanged-test RED remains:

- `cargo test -p jit --test cli test_command_exit_codes_config_validate_invalid_value_emits_4`: exit1 instead of4; `5046408a-rework-2-red-projection.log`.
- `cargo test -p jit --test cli cli_repo_workflow::project_config_tests`:10pass/4fail (human finding, stdout/stderr report, JSON envelope, valid-name repair); `5046408a-rework-2-red-config.log`.

Cycle3 commands, in collected order:

| Command/check | Result and first failure when applicable | Log |
|---|---|---|
| `cargo test -p jit --test cli test_config_validate_` before production edits | 1pass/5fail. Existing human finding absent; new absent-config sibling case exit1 vs4. New data-only test also incorrectly expected a `data` wrapper (`Null` vs`true`), which is a test-authoring error, not claimed behavioral RED. | `5046408a-rework-3-red-diagnostics.log` |
| `cargo test -p jit --test cli test_config_validate_needs_only_initialized_data_without_a_code_layout` after correcting only the new assertion and installing shared GitStandIn | Genuine RED: `data-only diagnostics need no code Git discovery`. Existing success shape is top-level valid/errors; original tests unchanged. | `5046408a-rework-3-red-data-only.log` |
| `cargo test -p jit --lib declarations::` after initial implementation | Compile failure: unused JitConfig import; dead load_index after factoring initialized validation. | `5046408a-rework-3-declarations.log` |
| Same declaration check after cleanup | Compile failure: seven existing test callers still require `load_index`. Restored its production API over shared data-only admission and canonical index validation, preserving those assertions. | `5046408a-rework-3-declarations-rerun.log` |
| Same declaration check after convergence | 108passed | `5046408a-rework-3-declarations-rerun-2.log` |
| `cargo test -p jit --lib storage::` | 512passed | `5046408a-rework-3-owner-storage__.log` |
| `cargo test -p jit --lib config` | 183passed (overlapping affected config owners, not an additive suite count) | `5046408a-rework-3-owner-config.log` |
| `cargo test -p jit --lib commands::bootstrap` | 13passed | `5046408a-rework-3-owner-commands__bootstrap.log` |
| Original malformed-config exit projection | 1passed, unchanged | `5046408a-rework-3-projection.log` |
| Project-config target filter | 20passed, including every original assertion and six new boundary tests | `5046408a-rework-3-project-config.log` |
| `cargo test -p jit --test cli --test contracts --no-fail-fast` | **FAIL**: CLI1222pass/3fail; contracts548pass/2fail. Full details below. Cargo continues both targets and libtest runs every test in each target. | `5046408a-rework-3-cli-contracts.log` |
| `cargo fmt --all -- --check` | PASS | `5046408a-rework-3-fmt-check.log` |
| `cargo clippy --workspace --all-targets` | PASS, zero warnings | `5046408a-rework-3-clippy.log` |
| Built-binary owned-temp registry sweep, no source changes | Nine applicable arms; six match, three mismatches (item list/search/recover). | `5046408a-rework-3-full-boundary-registry.json`; earlier subset `5046408a-rework-3-boundary-repros.json` retained |

The three `cargo fmt --all` edit-batch formatting logs are `5046408a-rework-3-format.log`, `...-format-2.log`, `...-format-3.log`. `git diff --check` is clean. Every queued command completed; none was cancelled. Checks used turnstile then shared full-CI locks, owned short /dev/shm TMPDIR created/trap-cleaned in the same escalation namespace, offline/no-sccache/nonincremental environment, empty RUSTC_WRAPPER and disk caches/targets. Before the final batch /tmp had about25.8GiB available and about76.7% free inodes. No unchanged broad library/doctest rerun was performed merely for freshness. Lead's configured full gate and two independent implementation reviews remain unrun for this composition because this investigation is not green and a material decision is required.

### Full-target failures, unchanged assertions

1. Log1251: `test_command_exit_codes_permission_denied_emits_5`: `Permission denied (os error 13)`, actual1 vs5. Shared I/O source chain needs preservation (proposal section1).
2. Log1260: `test_recorded_failure_arms_emit_the_canonical_error_envelope`: item list actual PARSE_ERROR vs INVALID_ARGUMENT. Complete nine-arm reproduction additionally proves item search and recover mismatches; none is omitted because the aggregate assertion stopped first.
3. Log1273: `test_worktree_exec_refuses_a_leftover_redo_record_without_applying_it`: actual12 vs required1. Required-root pending read preempts the command-owned under-lock refusal.
4. Log1845: `test_release_issue_returns_updated_issue`: `Cannot release: no acting identity for the audit trail`.
5. Log1860: `test_issue_lifecycle_works_without_coordinator`: same identity failure. No ambient identity was introduced to mask either owning-test failure.

## Mandatory audits

- Pre-edit configured review audit: zero reviews; `5046408a-rework-3-prior-reviews.json`.
- All seven linked main documents read/enumerated: `5046408a-rework-3-linked-docs.json`. Accepted amended design, diagnostics proposal and R1/R2 were read from absolute main paths; no self-merge. Main acceptance356f7596a/reference5fa92e83d provides authorization, archived preacceptance wording is preserved history.
- Deferred-marker audit: only historical design R1 lines61/63, closed by D26/D27/R3; `5046408a-rework-3-deferred-audit.txt`. No new hidden deferral.
- Per-finding owner/contract sweep: `5046408a-rework-3-owner-sweep.txt`. Subsequent complete registry sweep is recorded above. All30 previous rows are carried forward below, with additional actual findings.

## Cumulative resolution and audit table

Paths below are relative to `crates/jit/src/` unless `tests/` is explicit. Previous closed historical checks are carried as historical evidence, not represented as freshly rerun.

| # | Prior finding/audit | Current status and source/evidence |
|---|---|---|
| 1 | Gate2 malformed config validate emits1 instead of4 | **Closed in focused evidence.** Data-only report `commands/config.rs:74`, registered outcome `dispatch/config.rs:40–73`; unchanged projection passes. |
| 2 | Invalid project name missing from human finding | **Closed.** Same computation; unchanged `tests/cli_repo_workflow/project_config_tests.rs:127` passes. |
| 3 | Human findings stdout/summary stderr | **Closed.** Existing emitter and response untouched; test153 passes. |
| 4 | JSON VALIDATION_FAILED details valid/errors | **Closed.** Canonical outcome/leaf admission; test183 passes. |
| 5 | Valid-name repair blocked by invalid unrelated preimage | **Closed.** Required projection `commands/bootstrap.rs:109`; full edited postimage `commands/config.rs:235,368`; unchanged repair test421 passes. |
| 6 | Rework1 absent/synthetic ancestor NotFound | **Preserved closed.** Shared `DataReadSession::open_after_missing`, `storage/repository_state_store.rs:455–474`, and discovery518; storage512pass plus prior rework1/gate2 evidence. |
| 7 | Dependency removal/auto-ready recovery | **Preserved closed.** Unchanged `commands/dependency.rs:806`; rework1 library log166 and gate2 prior-regression clearance retained. |
| 8 | Repeated removed dependency is not found | **Preserved closed.** Unchanged dependency.rs913; rework1 library log170 retained. |
| 9 | Dependency removal graph-block event | **Preserved closed.** Unchanged dependency.rs859; rework1 library log169 retained. |
| 10 | Document add typed invalid-path error | **Preserved closed.** Unchanged commands/document.rs2394; rework1 library log175 retained. |
| 11 | Gate update_gate doctest | **Preserved closed.** Unchanged commands/gate.rs1249; rework1 doc log23 and gate2 all25doctests. |
| 12 | issue_progress doctest | **Preserved closed.** Unchanged commands/issue.rs845; rework1 doc log28/gate2. |
| 13 | issue_children doctest | **Preserved closed.** Unchanged commands/issue.rs770; rework1 doc log29/gate2. |
| 14 | Parallel exact-store absence fallback | **Preserved closed.** json.rs read_exact_data_store continues through DataReadSession; no fallback restored. |
| 15 | Published ancestor must not become data authority | **Preserved closed.** reader guard455–474; deterministic owning test `storage/repository_state_store_tests.rs:3379` still passes. |
| 16 | Publication/ancestor/root replacement invalidates | **Preserved closed.** Canonical full/projection migration retains tests3351/3400; storage512pass. |
| 17 | Configured reviews/deferred audit | Zero configured reviews; seven docs audited. Diagnostics design R1 FAIL preserved, R2 PASS accepted; no implementation review substituted. |
| 18 | Manual Git setup in selected-subdir JSON test | **Preserved closed.** Existing GitRepository fixture in json.rs2762 unchanged; storage suite passes. |
| 19 | Historical R1:61 recovery-options marker | Closed by accepted D26/D27/R3, not an open deferral; unchanged audit evidence. |
| 20 | Historical R1:63 proposals-not-implemented marker | Recorded-time statement superseded by accepted optionA; original implementation report retained. |
| 21 | Original-root durable authority | **Preserved closed.** redo_record.rs48/130/226, original-root recovery test3412 and replay/restart tests3512/3536/3572 unchanged and pass in storage suite. |
| 22 | Config-to-layout admission | **Preserved.** Observation616, selection812 refresh/compare/admit; tests3223/3246/3267 preserve handoff, unrelated commit, retained and claim-first behavior. |
| 23 | Data/code/document/projected authority | **Preserved.** Existing split WorktreePaths and JSON code-root accessors unchanged; diagnostics route `dispatch/mod.rs:153` has no executor/Git. New no-Git diagnostic test446 passes. |
| 24 | Removed HEAD tier and raw symlink ambiguity | **Preserved.** No HEAD issue tier restored; shared raw-component no-follow explicit root helper bootstrap238 plus existing symlink test passes. |
| 25 | Original policy ordering/exact footprint | **Preserved for implemented correction.** Recovery bootstrap94 before projection109; governed original-policy test468 passes. Exactly ten changed files. New boundary/fixture options remain unedited pending ruling. |
| 26 | Diagnostics R1 omitted storage test owner | **Closed in implementation.** Authorized tenth owner mechanically migrates binding fixture3193 and full/projection assertions3351–3396; all original semantics retained, storage512pass. |
| 27 | Index+declarations must share admission | **Closed.** Observation attempt562 captures both before one admit; deterministic composition test3314 passes. Ordinary index load uses the same validator, not two diagnostic captures. |
| 28 | Registered findings admission | **Closed.** dispatch/config.rs58–73 looks up the actual config_validate registered leaf and admits the canonical outcome before emission; unchanged report/exit tests pass. |
| 29 | Config absent must validate siblings; storage errors not findings | **Authored/sibling path closed; I/O classification finding31 open.** commands/config.rs79–112 only converts ConfigurationAssemblyError; tests470/589/611 pass absent valid/invalid siblings, index and capability failures. |
| 30 | Diagnostic computation must not reread environment | **Closed.** dispatch/mod.rs141–156 captures once; ConfigValidationReport::for_invocation/at_data_root consumes explicit inputs only. Existing executor API delegates to the same computation. |
| 31 | New: unreadable index loses permission code | **Open.** Transparent RepositoryStateStoreError::Io source at89–90; unchanged projection test fails5vs1. In-footprint source-preservation repair proposed, not applied. |
| 32 | New: item list malformed config classification | **Open.** Early canonical root projection preempts cached_config adapter commands/mod.rs2908. Registry542; actual PARSE_ERROR vs INVALID_ARGUMENT. Steward boundary decision required. |
| 33 | New sweep: item search same hidden mismatch | **Open.** Registry551; independently reproduced in complete nine-arm JSON. Same shared decision as32. |
| 34 | New sweep: recover malformed config classification | **Open.** Registry782; bootstrap preempts dispatch/claim.rs151 RecoveryFailedError; actual PARSE_ERROR vs recovery_failed. Committed replay ordering must remain intact. |
| 35 | New: worktree exec pending redo | **Open.** Command owner commands/worktree.rs82 refuses pending under its lock, but bootstrap read returns12 before it. Existing test70 requires1/path/no child/unchanged bytes. Data-only command preparation versus explicit cutover is a steward choice. |
| 36 | New: release result test lacks actor | **Open.** tests/fast_issue/mutation_result_tests.rs52–65, canonical actor resolve commands/claim.rs272, release producer commands/mod.rs3055. Explicit-input scope proposed; no ambient masking. |
| 37 | New: no-coordinator lifecycle release lacks actor | **Open.** tests/fast_issue/test_no_coordinator.rs12–63; same actor owner as36. Keep no-coordinator property and attributable release. |
| 38 | New-test success-envelope authoring mismatch | **Corrected transparently before production fix.** Initial Null-vs-true evidence retained; only new test corrected to existing top-level shape, then genuine Git-discovery RED recollected. |
| 39 | Refactored index loader compile cleanup | **Closed.** Initial unused/dead loader and then seven test-call compile failures retained. Production load_index now uses shared admission/validator; original assertions unchanged, storage512pass. |
| 40 | Complete malformed-config/pending registry sweep | Nine arms enumerated directly from registry, six match and three open32–34. Universal eleven-command pending-read projection passes; separate exec exception remains35. No later corpus arm is hidden by the first assertion. |

## Next action and limits

Steward/lead must choose the boundary and omitted-owner correction described in the proposal before further edits. The in-scope permission source fix is identified but intentionally not applied while the combined source is frozen for this material ruling. No configuration-report assertion, failure registry, worktree-exec assertion or release identity contract was weakened. No default code root, compatibility JitConfig, second parser, policy overlay or reader recovery was added. Full CLI/contracts are collected but not green; full configured gate/reviews and completion remain outstanding. The worker will not edit source after this frozen return without a new explicit dispatch.


## Proposal-only follow-up after steward selected A

A later explicit dispatch selected shared typed item/recover adapters and data-only worktree exec, with the I/O-source repair, for fresh bounded independent design review. The proposed total is thirteen files (the existing ten plus commands/mod.rs, commands/worktree.rs and dispatch/worktree.rs); this is not implementation authorization. B/registry cutover is not selected and no retry reset is granted. The revised `5046408a-rework-3-boundary-proposal.md` pins root/pending/index/lock ordering, cleanup, child cwd/stdio/status and D25 semantics. The earlier alternatives remain verbatim in `5046408a-rework-3-boundary-proposal-before-A.md`.

Rows36/37 are now confirmed unchanged-main failures, rather than merely suspected latent concerns. Authorized main-only focused checks at f64105f313d55b83b8832b1d67f2cd30d31cb9fd reproduce both independently under sanitized actor inputs; the already-built worker binary reproduces both under the same inputs. Main stayed clean/source-identical, targets were separate, and every check was collected. Evidence is `5046408a-actor-baseline-main.json`, `5046408a-actor-baseline-worker.json`, their four named logs and `5046408a-actor-source-audit.json`. No source, test assertion or actor API was edited. The separate four-file same-epic corrective-task proposal is `5046408a-actor-task-proposal.md`; it preserves lookup-before-identity error precedence, explicit Assignee audit attribution and one producer, and proposes mainfix→504refresh sequencing outside the53-node manifest with no epicREQ credit. No task, dependency or dispatch was created.

504 HEAD/diff hash and source freeze above are unchanged; no command remains active. All work in this follow-up is scratch proposal/evidence plus authorized baseline builds/tests, with no source/tracker/commit/merge action.
